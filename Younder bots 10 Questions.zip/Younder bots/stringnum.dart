void main() {
  String input = "a1b10";
  String output = "";
  int i = 0;
  while (i < input.length) {
    String char = input[i];
    i++;
    String numStr = "";
    while (i < input.length && input[i].contains(RegExp(r'[0-9]'))) {
      numStr += input[i];
      i++;
    }
    int count = int.parse(numStr);
    for (int j = 0; j < count; j++) {
      output += char;
    }
  }
  print(output);
}
