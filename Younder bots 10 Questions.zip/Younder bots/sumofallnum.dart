void main() {
  int num = 641108;
  int sum = 0, temp = 0;
  //double num1 = 0;
  while (num != 0) {
    temp = num % 10;
    sum += temp;
    num =(num/10).toInt();
    
  }
  print(sum);
}
