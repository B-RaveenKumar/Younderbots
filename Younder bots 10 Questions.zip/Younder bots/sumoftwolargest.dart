void main() {
  List arr = [10, 9, 3, 4, 5, 6, 7, 13];
  arr.sort();
  int sum = arr[arr.length-2] + arr[arr.length - 1];
  print(sum);
}
